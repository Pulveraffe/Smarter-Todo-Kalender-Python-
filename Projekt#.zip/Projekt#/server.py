from flask import Flask, jsonify, send_from_directory
import os
import json

# Ordnerstruktur: 
# - server.py
# - Speicher/todos.json
# - static/index.html, script.js, style.css

app = Flask(__name__, static_folder="static")
TODO_PATH = os.path.join(os.path.dirname(__file__), "Speicher", "todos.json")

# API-Endpoint für ToDos
@app.route("/api/todos", methods=["GET"])
def get_todos():
    if not os.path.exists(TODO_PATH):
        return jsonify([])  # Leere Liste, falls Datei fehlt
    with open(TODO_PATH, "r", encoding="utf-8") as f:
        try:
            todos = json.load(f)
        except json.JSONDecodeError:
            todos = []
    return jsonify(todos)

# Startseite (index.html)
@app.route("/")
def serve_index():
    return send_from_directory(app.static_folder, "index.html")

# Weitere statische Dateien (CSS, JS)
@app.route("/<path:path>")
def serve_static_files(path):
    return send_from_directory(app.static_folder, path)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=True)
