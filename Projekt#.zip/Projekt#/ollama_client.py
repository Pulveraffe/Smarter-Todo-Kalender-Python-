import requests

OLLAMA_URL = "http://localhost:11434/api/generate"

def generate_with_ollama(model: str, prompt: str):
    """
    Sendet einen Prompt an Ollama und gibt die rohe Antwort zurück.
    """
    try:
        response = requests.post(
            OLLAMA_URL,
            json={
                "model": model,
                "prompt": prompt,
                "stream": False
            },
            timeout=60
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Fehler bei der Verbindung zu Ollama: {e}")
        return None
