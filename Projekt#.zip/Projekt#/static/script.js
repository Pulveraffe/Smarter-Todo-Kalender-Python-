// script.js (ersetzt die alte Version)
// - Lädt die Todos von /api/todos
// - Baut den Monatskalender
// - Markiert Tage mit Tasks
// - Zeigt beim Klicken auf einen Tag die Tasks dieses Tages im Modal an
// - "Alle Termine anzeigen" bleibt erhalten

const calendarElement = document.getElementById("calendar");
const monthYearElement = document.getElementById("monthYear");
const prevMonthBtn = document.getElementById("prevMonth");
const nextMonthBtn = document.getElementById("nextMonth");
const showAllTasksBtn = document.getElementById("showAllTasks");
const modal = document.getElementById("taskListModal");
const closeModalBtn = document.getElementById("closeModal");
const allTasksElement = document.getElementById("allTasks");
const modalTitleElement = modal.querySelector("h2"); // vorhandene h2 im Modal

let currentDate = new Date();
let tasks = [];

/**
 * Lade Tasks aus dem Backend
 */
async function fetchTasks() {
  try {
    const res = await fetch("/api/todos");
    if (!res.ok) throw new Error("Failed to fetch todos");
    const data = await res.json();
    return Array.isArray(data) ? data : [];
  } catch (e) {
    console.error("Fehler beim Laden der Todos:", e);
    return [];
  }
}

/**
 * Parse einfache Datumsangaben, Rückgabe: "DD.MM" (wie in deiner JSON)
 * - akzeptiert "DD.MM", "DD.MM.YYYY", "heute", "morgen", "übermorgen"
 * - Wenn nicht erkennbar -> null
 */
function normalizeToDDMM(dueText) {
  if (!dueText) return null;
  const txt = String(dueText).trim();

  // Match DD.MM.YYYY oder DD.MM
  const match = txt.match(/(\d{1,2})\.(\d{1,2})(?:\.(\d{2,4}))?/);
  if (match) {
    const day = Number(match[1]);
    const month = Number(match[2]);
    return `${String(day).padStart(2,"0")}.${String(month).padStart(2,"0")}`;
  }

  // relative Daten wie heute/morgen/übermorgen
  const today = new Date();
  const lower = txt.toLowerCase();

  if (lower.includes("heute")) {
    return `${String(today.getDate()).padStart(2,"0")}.${String(today.getMonth()+1).padStart(2,"0")}`;
  }
  if (lower.includes("morgen")) {
    const d = new Date(today);
    d.setDate(d.getDate() + 1);
    return `${String(d.getDate()).padStart(2,"0")}.${String(d.getMonth()+1).padStart(2,"0")}`;
  }
  if (lower.includes("übermorgen")) {
    const d = new Date(today);
    d.setDate(d.getDate() + 2);
    return `${String(d.getDate()).padStart(2,"0")}.${String(d.getMonth()+1).padStart(2,"0")}`;
  }

  // fallback
  return null;
}



/**
 * Öffnet das Modal und zeigt eine Liste von Aufgaben (items: Array of {task,due})
 * title: String
 */
function openModalWithItems(title, items) {
  modalTitleElement.textContent = title || "Termine";
  allTasksElement.innerHTML = "";
  if (!items || items.length === 0) {
    const li = document.createElement("li");
    li.textContent = "Keine Aufgaben gefunden.";
    allTasksElement.appendChild(li);
  } else {
    items.forEach(it => {
      const li = document.createElement("li");
      const dueText = it.due ? it.due : "kein Datum";
      li.textContent = `${dueText} → ${it.task}`;
      allTasksElement.appendChild(li);
    });
  }
  modal.style.display = "block";
}

/**
 * Modal schließen
 */
function closeModal() {
  modal.style.display = "none";
}

/**
 * Erzeuge den Kalender für den aktuellen Monat und hänge Click-Handler an Tage mit Tasks
 */
async function buildCalendar() {
  calendarElement.innerHTML = "";
  tasks = await fetchTasks();

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  // Monatstitel setzen
  const monthNames = [
    "Januar", "Februar", "März", "April", "Mai", "Juni",
    "Juli", "August", "September", "Oktober", "November", "Dezember"
  ];
  monthYearElement.textContent = `${monthNames[month]} ${year}`;

  // Erster und letzter Tag des Monats
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);

  
  let leadingEmpty = (firstDay.getDay() + 6) % 7; // montag = 0
  // Wenn du Montag als ersten Wochentag willst, uncomment:
  // leadingEmpty = (leadingEmpty + 6) % 7;

  for (let i = 0; i < leadingEmpty; i++) {
    const emptyDiv = document.createElement("div");
    emptyDiv.textContent = "";
    calendarElement.appendChild(emptyDiv);
  }

  // Tage des Monats erzeugen
  for (let day = 1; day <= lastDay.getDate(); day++) {
    const isToday = new Date().toDateString() === new Date(year, month, day).toDateString();
    const dateDiv = document.createElement("div");

    dateDiv.classList.add("calendar-day");
    dateDiv.textContent = day;

    // Build formatted string DD.MM (wie in JSON)
    const formattedDate = `${String(day).padStart(2,"0")}.${String(month+1).padStart(2,"0")}`;
    if (isToday) {
     dateDiv.classList.add("today");
     }
    // Finde Tasks, die für dieses Datum gelten:
    // Wir vergleichen gegen task.due (ebenfalls DD.MM oder unscharfe Texte).
 const dayTasks = tasks.filter(task => {
  if (!task.due) return false;
  const normalizedDue = normalizeToDDMM(task.due); // DD.MM
  return normalizedDue === formattedDate; // beide DD.MM
});


    if (dayTasks.length > 0) {
      dateDiv.classList.add("has-task");
      dateDiv.title = dayTasks.map(t => t.task).join(", ");

      // Klick-Handler: beim Klicken Modal mit den Tasks dieses Tages öffnen
      dateDiv.addEventListener("click", () => {
        openModalWithItems(`Aufgaben am ${formattedDate}`, dayTasks);
      });
    } else {
      // auch Tage ohne Tasks könnten klickbar sein (optional)
      dateDiv.addEventListener("click", () => {
        // falls du willst, zeige leere Liste mit Datum
        openModalWithItems(`Aufgaben am ${formattedDate}`, []);
      });
    }

    calendarElement.appendChild(dateDiv);
  }
}

/**
 * Show all tasks in modal
 */
showAllTasksBtn.addEventListener("click", async () => {
  tasks = await fetchTasks();
  openModalWithItems("Alle Termine", tasks);
});

// Modal schließen via X
closeModalBtn.addEventListener("click", closeModal);

// Modal schließen beim Klick außerhalb der Box
window.addEventListener("click", (e) => {
  if (e.target === modal) closeModal();
});

// Monatsnavigation
prevMonthBtn.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() - 1);
  buildCalendar();
});
nextMonthBtn.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() + 1);
  buildCalendar();
});

// initial render
buildCalendar();

