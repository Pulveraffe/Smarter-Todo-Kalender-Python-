import json
from ollama_client import generate_with_ollama

MODEL = "qwen2.5:3b-instruct"

def query_ollama(chaotic_text: str):
    """
    Sendet den chaotischen Text an Ollama und fordert eine streng JSON-konforme Antwort an.
    Gibt eine Python-Liste von ToDo-Objekten zurück.
    """
    prompt = f"""
    Du bist ein JSON-Generator. Analysiere den folgenden Text und extrahiere strukturierte ToDos.
    Gib ausschließlich gültiges JSON zurück. Verwende dieses Format:

    [
      {{
        "task": "<kurze Beschreibung der Aufgabe>",
        "due": "<Datum oder relative Angabe>"
      }}
    ]

    Text: "{chaotic_text}"
    """

    result = generate_with_ollama(MODEL, prompt)

    if not result or "response" not in result:
        return []

    try:
        todos = json.loads(result["response"])
        if isinstance(todos, dict):
            todos = [todos]
        return todos
    except json.JSONDecodeError:
        print("Fehler: Modell hat kein gültiges JSON geliefert.")
        return []
