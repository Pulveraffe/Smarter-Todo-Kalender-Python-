import os
import json
import dateparser
from dateparser.search import search_dates
from ollama_interface import query_ollama

# === Speicherpfad für ToDos ===
TODOS_PATH = r"C:\Users\user-vITA17\Desktop\Projekt#\Speicher\todos.json"


def normalize_due_date(due_str: str):
    """
    Wandelt natürliche deutsche Datumsangaben zuverlässig in DD.MM.YYYY um.
    Unterstützt:
    - Absolute Daten: 12.09, 12.09.2025
    - Relative Daten: morgen, übermorgen, nächsten Freitag, nächste Woche Dienstag
    - Eingebettete Angaben: "am nächsten Freitag um 12 Uhr"
    Gibt None zurück, wenn kein Datum erkannt wird.
    """
    if not due_str:
        return None

    txt = str(due_str).strip()

    # Parsing-Einstellungen: bevorzugt zukünftige Daten, deutsche Sprache
    settings = {'DATE_ORDER': 'DMY', 'PREFER_DATES_FROM': 'future'}

    # 1) Direkter Parse-Versuch
    try:
        parsed = dateparser.parse(txt, languages=['de'], settings=settings)
        if parsed:
            return parsed.strftime("%d.%m.%Y")
    except Exception:
        pass

    # 2) Suche nach Datumsausdrücken innerhalb längerer Texte
    try:
        found = search_dates(txt, languages=['de'], settings=settings)
        if found and len(found) > 0:
            dt = found[0][1]
            return dt.strftime("%d.%m.%Y")
    except Exception:
        pass

    # 3) Heuristik: "nächsten" → "nächster" / "nächste" → "nächster"
    alt = txt.lower().replace("nächsten", "nächster").replace("nächste", "nächster")
    try:
        parsed_alt = dateparser.parse(alt, languages=['de'], settings=settings)
        if parsed_alt:
            return parsed_alt.strftime("%d.%m.%Y")
    except Exception:
        pass

    # 4) Kein Datum gefunden
    return None


def load_todos():
    """Lädt bestehende ToDos aus der JSON-Datei."""
    if os.path.exists(TODOS_PATH):
        with open(TODOS_PATH, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return []
    return []


def save_todos(todos):
    """Speichert die ToDos in einer JSON-Datei."""
    with open(TODOS_PATH, "w", encoding="utf-8") as f:
        json.dump(todos, f, ensure_ascii=False, indent=2)
    print(f"\nAlle ToDos wurden gespeichert in: {TODOS_PATH}")


def main():
    # Nutzerinput abfragen
    chaotic_text = input("Gib deinen chaotischen ToDo-Text ein: ")

    # Anfrage an Ollama-Modell
    ollama_response = query_ollama(chaotic_text)

    if not ollama_response:
        print("Fehler: Keine Antwort vom Modell erhalten.")
        return

    # Bestehende ToDos laden
    todos = load_todos()

    print("\n=== Strukturierte ToDos ===")
    for idx, todo in enumerate(ollama_response, start=1):
        task = todo.get("task", "Keine Aufgabe")
        due_raw = todo.get("due", "")

        # Datum robust normalisieren
        due = normalize_due_date(due_raw)

        todos.append({
            "task": task,
            "due": due
        })

        print(f"{idx}. {task} (Fällig: {due if due else 'Kein Datum'})")

    # ToDos speichern
    save_todos(todos)


if __name__ == "__main__":
    main()
